<?php
/*
 * Template Name: Para Veterinarios
 */
get_header();
$img_dir = get_template_directory_uri() . '/assets/images';
?>

<section class="hero" style="background:linear-gradient(180deg,#005542 0%,#00745B 100%);color:#fff">
  <div class="blob blob-1" style="background:var(--yellow);opacity:0.2"></div>
  <div class="wrap hero-grid">
    <div>
      <span class="badge" style="background:rgba(255,255,255,0.15);color:#fff">PARA VETERINARIOS</span>
      <h1 style="color:#fff">Atiende consultas veterinarias en línea con PlusKotas</h1>
      <p class="sub" style="color:rgba(255,255,255,0.85)">Únete a una plataforma que conecta a dueños de mascotas con veterinarios verificados. Maneja tu disponibilidad, atiende por videollamada, ofrece orientación profesional y genera ingresos desde donde estés.</p>
      <div class="ctas">
        <a href="https://app.pluskotas.com/" target="_blank" rel="noopener" class="btn btn-primary" style="background:var(--yellow);color:var(--ink)"><i data-lucide="user-plus"></i>Registrarme como veterinario</a>
        <a href="#how" class="btn btn-secondary" style="border-color:rgba(255,255,255,0.3);color:#fff">Ver cómo funciona<i data-lucide="arrow-right"></i></a>
      </div>
      <p style="margin-top:24px;color:rgba(255,255,255,0.7);font-size:14px;max-width:480px">Plataforma diseñada para consultas virtuales, seguimiento, historial médico y comunicación clara con dueños de mascotas.</p>
    </div>
    <div class="phone-stage">
      <div class="float-card fc-1"><i data-lucide="badge-check"></i>Perfil verificado</div>
      <div class="float-card fc-2"><i data-lucide="calendar-plus"></i>Nueva cita</div>
      <div class="float-card fc-3"><i data-lucide="clock"></i>Disponibilidad configurada</div>
      <div class="float-card fc-4"><i data-lucide="file-text"></i>Reporte registrado</div>
      <img src="<?php echo esc_url( $img_dir . '/screens/web-perfil-vet.png' ); ?>" alt="Portal para veterinarios" style="border-radius:18px;box-shadow:var(--shadow-floating);max-width:480px;width:100%;position:relative;z-index:2">
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">¿Por qué unirse?</span>
      <h2 style="margin-top:14px">Una nueva forma de ofrecer atención veterinaria</h2>
    </div>
    <div class="bento-row" style="grid-template-columns:repeat(4,1fr);gap:20px">
      <div class="feat-card"><div class="feat-icon"><i data-lucide="dollar-sign"></i></div><h3>Genera ingresos adicionales</h3><p style="margin-top:8px">Atiende consultas virtuales en tus horarios disponibles.</p></div>
      <div class="feat-card"><div class="feat-icon"><i data-lucide="clock"></i></div><h3>Trabaja con flexibilidad</h3><p style="margin-top:8px">Define tu disponibilidad y presta servicios desde donde estés.</p></div>
      <div class="feat-card"><div class="feat-icon"><i data-lucide="users"></i></div><h3>Llega a más dueños</h3><p style="margin-top:8px">Conecta con usuarios que buscan orientación veterinaria confiable.</p></div>
      <div class="feat-card"><div class="feat-icon"><i data-lucide="briefcase-medical"></i></div><h3>Herramientas para atender mejor</h3><p style="margin-top:8px">Consulta información relevante de la mascota y su historial médico.</p></div>
    </div>
  </div>
</section>

<section id="how" style="background:var(--mint)">
  <div class="wrap">
    <div class="section-head"><span class="eyebrow">Proceso</span><h2 style="margin-top:14px">Cómo funciona para veterinarios</h2></div>
    <div class="steps" style="grid-template-columns:repeat(5,1fr)">
      <div class="step"><div class="step-num">1</div><h3 style="font-size:16px">Regístrate</h3><p style="margin-top:8px;font-size:14px">Agrega tu experiencia, especialidad y datos profesionales.</p></div>
      <div class="step"><div class="step-num">2</div><h3 style="font-size:16px">Revisión</h3><p style="margin-top:8px;font-size:14px">El equipo de PlusKotas verifica tu información.</p></div>
      <div class="step"><div class="step-num">3</div><h3 style="font-size:16px">Configura agenda</h3><p style="margin-top:8px;font-size:14px">Define cuándo puedes atender consultas.</p></div>
      <div class="step"><div class="step-num">4</div><h3 style="font-size:16px">Atiende</h3><p style="margin-top:8px;font-size:14px">Habla por videollamada con dueños de mascotas.</p></div>
      <div class="step"><div class="step-num">5</div><h3 style="font-size:16px">Reporta</h3><p style="margin-top:8px;font-size:14px">Documenta recomendaciones y próximos pasos.</p></div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="section-head"><span class="eyebrow">Herramientas</span><h2 style="margin-top:14px">Todo lo que necesitas para una consulta virtual organizada</h2></div>
    <div class="uses">
      <div class="use-card"><i data-lucide="video"></i><div>Videollamadas dentro de la app</div></div>
      <div class="use-card"><i data-lucide="user-circle"></i><div>Perfil profesional</div></div>
      <div class="use-card"><i data-lucide="calendar"></i><div>Disponibilidad y agenda</div></div>
      <div class="use-card"><i data-lucide="folder-heart"></i><div>Acceso al historial de la mascota</div></div>
      <div class="use-card"><i data-lucide="upload"></i><div>Acceso a documentos e imágenes</div></div>
      <div class="use-card"><i data-lucide="file-text"></i><div>Reporte posterior a la consulta</div></div>
      <div class="use-card"><i data-lucide="repeat"></i><div>Citas de seguimiento</div></div>
      <div class="use-card"><i data-lucide="life-buoy"></i><div>Soporte de PlusKotas</div></div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="trust-block">
      <div class="section-head"><span class="eyebrow" style="color:var(--yellow)">Estándares</span><h2 style="margin-top:14px">Una plataforma seria para atención veterinaria responsable</h2><p>PlusKotas promueve una atención veterinaria virtual responsable. Las consultas en línea deben respetar los límites profesionales, legales y clínicos aplicables.</p></div>
      <div class="trust-cards" style="grid-template-columns:repeat(3,1fr)">
        <div class="trust-c"><i data-lucide="shield-check"></i><h3>Reglas claras</h3><p>de atención virtual</p></div>
        <div class="trust-c"><i data-lucide="message-circle"></i><h3>Comunicación profesional</h3><p>con usuarios</p></div>
        <div class="trust-c"><i data-lucide="clipboard-check"></i><h3>Registro obligatorio</h3><p>de información relevante</p></div>
        <div class="trust-c"><i data-lucide="alert-triangle"></i><h3>Límites claros</h3><p>sobre atención virtual</p></div>
        <div class="trust-c"><i data-lucide="siren"></i><h3>No atendemos emergencias</h3><p>pero siempre tratamos de ayudar</p></div>
        <div class="trust-c"><i data-lucide="life-buoy"></i><h3>Soporte</h3><p>del equipo PlusKotas</p></div>
      </div>
    </div>
  </div>
</section>

<section style="background:var(--aqua)">
  <div class="wrap">
    <div class="section-head"><span class="eyebrow">FAQ</span><h2 style="margin-top:14px">Preguntas frecuentes</h2></div>
    <div class="faq-list">
      <div class="faq-item"><div class="faq-q">¿Cómo puedo registrarme como veterinario en PlusKotas?</div><div class="faq-a"><p>Puedes registrarte desde una laptop o equipo de escritorio. El proceso requiere: ingresar tu nombre completo, proporcionar tu correo electrónico, crear una contraseña y validarla para confirmar el acceso.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Qué requisitos necesito para ser parte de la red?</div><div class="faq-a"><p>La plataforma solicitará: escaneo del título profesional (por ambos lados), el documento oficial de aval del título y experiencia mínima de 5 años ejerciendo como veterinario con constancias de trabajo. Pueden participar médicos veterinarios de distintos países, siempre que su título esté debidamente reconocido.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿PlusKotas valida mis credenciales profesionales?</div><div class="faq-a"><p>Sí. PlusKotas valida todas las credenciales profesionales. Solo después de esta validación podrás formar parte de la red y atender consultas.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Puedo decidir mis horarios de atención?</div><div class="faq-a"><p>Sí. Cada veterinario puede decidir sus propios horarios a través del calendario de disponibilidad en la plataforma.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Cuánto gano por cada consulta?</div><div class="faq-a"><p>Por cada consulta realizada, el veterinario recibe el 70% del valor de la consulta. El 30% restante corresponde a la plataforma por concepto de gestión y funcionamiento.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Puedo combinar consultas online con mi consulta presencial?</div><div class="faq-a"><p>Sí. Como veterinario puedes combinar ambas modalidades perfectamente.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Qué pasa si no puedo atender una consulta asignada?</div><div class="faq-a"><p>Las consultas se generan en función de tu disponibilidad. Al confirmar una cita, asumes la responsabilidad de atenderla. Al cancelar una cita confirmada, se aplicará una pequeña penalidad por costos de transferencia.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Puedo hacer contacto con los usuarios afuera de la app?</div><div class="faq-a"><p>No. Hacer contacto con los usuarios afuera de la app va en contra de los términos y condiciones.</p></div></div>
    </div>
    <div style="text-align:center;margin-top:36px">
      <a href="<?php echo esc_url( add_query_arg( 'cat', 'vet-pros', get_permalink( get_page_by_path( 'preguntas-frecuentes' ) ) ) ); ?>" class="btn btn-secondary">Ver todas las preguntas <i data-lucide="arrow-right"></i></a>
    </div>
  </div>
</section>

<section id="registrarse">
  <div class="wrap">
    <div class="final">
      <div style="text-align:center;max-width:720px;margin:0 auto;position:relative;z-index:2">
        <h2>Forma parte de la red veterinaria de PlusKotas</h2>
        <p style="margin-top:18px;font-size:17px">Ayuda a más dueños de mascotas a recibir orientación confiable y ofrece tus servicios desde una plataforma diseñada para la atención veterinaria virtual.</p>
        <a href="https://app.pluskotas.com/" target="_blank" rel="noopener" class="btn btn-primary" style="background:var(--yellow);color:var(--ink);margin-top:24px"><i data-lucide="user-plus"></i>Registrarme como veterinario</a>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
