<?php
/*
 * Template Name: Quiénes Somos
 */
get_header();
?>

<section class="page-hero">
  <span class="eyebrow">Quiénes somos</span>
  <h1>Creamos PlusKotas para hacer más simple el cuidado de las mascotas</h1>
  <p>Somos una app pensada para ayudar a los dueños de mascotas a organizar su salud, recibir orientación veterinaria y cuidar mejor a quienes forman parte de la familia.</p>
</section>

<section>
  <div class="wrap">
    <div class="bento-row" style="grid-template-columns:1fr 1fr">
      <div class="feat-card" style="background:var(--mint)">
        <div class="feat-icon"><i data-lucide="target"></i></div>
        <h3>Misión</h3>
        <p style="margin-top:10px;font-size:15px">Apoyar a dueños de mascotas en el cuidado de sus compañeros favoritos.</p>
      </div>
      <div class="feat-card" style="background:var(--mint-2)">
        <div class="feat-icon"><i data-lucide="eye"></i></div>
        <h3>Visión</h3>
        <p style="margin-top:10px;font-size:15px">Crear la mejor plataforma digital para el cuidado de mascotas.</p>
      </div>
    </div>
  </div>
</section>

<section style="background:var(--aqua)">
  <div class="wrap">
    <div class="section-head"><span class="eyebrow">Valores</span><h2 style="margin-top:14px">Lo que nos guía</h2></div>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:20px">
      <div class="feat-card">
        <div class="feat-icon"><i data-lucide="shield-check"></i></div>
        <h3>Confiable</h3>
        <p style="margin-top:10px;font-size:15px">Nuestros clientes confían en que podemos apoyarles con la salud y bienestar de sus compañeros y nosotros devolvemos esa confianza con información, precisión y apoyo profesional.</p>
      </div>
      <div class="feat-card">
        <div class="feat-icon"><i data-lucide="heart"></i></div>
        <h3>Amistoso</h3>
        <p style="margin-top:10px;font-size:15px">Nuestro servicio crea una atmósfera y sentimiento positivo para nuestros clientes donde se sienten apoyados.</p>
      </div>
      <div class="feat-card">
        <div class="feat-icon"><i data-lucide="zap"></i></div>
        <h3>Simple</h3>
        <p style="margin-top:10px;font-size:15px">Una parada para resolver varios problemas fácilmente. Menos es más, venimos a facilitar y simplificar la manera en que nuestros clientes cuidan a sus mascotas.</p>
      </div>
      <div class="feat-card">
        <div class="feat-icon"><i data-lucide="badge-check"></i></div>
        <h3>Integridad</h3>
        <p style="margin-top:10px;font-size:15px">Poner a nuestros clientes y sus mascotas primero es importante y nos permite hacer lo correcto en cada paso del proceso.</p>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="trust-block">
      <div class="section-head">
        <h2>Cuidado responsable</h2>
        <p>PlusKotas es una herramienta de orientación y organización del cuidado de tu mascota. Las consultas en línea no reemplazan la atención presencial en emergencias. Si tu mascota presenta síntomas graves, debes acudir inmediatamente a una clínica veterinaria.</p>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
