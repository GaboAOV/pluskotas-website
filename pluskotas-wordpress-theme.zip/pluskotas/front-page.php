<?php get_header(); ?>

<?php
$img_dir   = get_template_directory_uri() . '/assets/images';
$gplay_url = 'https://play.google.com/store/apps/details?id=com.avantelogic.pluskotas&pcampaignid=web_share';
$gplay_svg = '<svg viewBox="0 0 512 512" fill="currentColor" style="width:18px;height:18px;flex-shrink:0" aria-hidden="true"><path d="M325.3 234.3L104.6 13l280.8 161.2-60.1 60.1zM47 0C34 6.8 25.3 19.2 25.3 35.3v441.3c0 16.1 8.7 28.5 21.7 35.3l232.6-232.5L47 0zM425.2 225.6l-58.9-33.9-65.7 64.5 65.7 64.5 60.1-34.3c17.2-9.8 17.2-37 0-46.8v-.5l-.7-13.9-.5-.6zm-345 239.6l280.8-161.2-60.1-60.1L47 464.2z"/></svg>';
$apple_svg = '<svg viewBox="0 0 814 1000" fill="currentColor" style="width:16px;height:20px;flex-shrink:0" aria-hidden="true"><path d="M788.1 340.9c-5.8 4.5-108.2 62.2-108.2 190.5 0 148.4 130.3 200.9 134.2 202.2-.6 3.2-20.7 71.9-68.7 141.9-42.8 61.6-87.5 123.1-155.5 123.1s-85.5-39.5-164-39.5c-76 0-103.7 40.8-165.9 40.8s-105-57.8-155.5-127.4C46 790.7 0 663 0 541.8c0-207.5 135.4-317.3 269-317.3 70.1 0 128.4 46.4 172.5 46.4 42.8 0 109.2-49.9 190.5-49.9 30.8 0 130.3 2.6 198.3 99.2zm-234-181.5c31.1-36.9 53.1-88.1 53.1-139.3 0-7.1-.6-14.3-1.9-20.1-50.6 1.9-110.8 33.7-147.1 75.8-28.5 32.4-55.1 83.6-55.1 135.5 0 7.8 1.3 15.6 1.9 18.1 3.2.6 8.4 1.3 13.6 1.3 45.4 0 102.5-30.4 135.5-71.3z"/></svg>';
?>

<!-- HERO -->
<section class="hero">
  <div class="blob blob-1"></div>
  <div class="blob blob-2"></div>
  <div class="wrap hero-grid">
    <div>
      <span class="badge">🎉 Promoción de lanzamiento: 6 meses Premium gratis</span>
      <h1>Todo el cuidado que tu mascota merece, en la palma de tu mano.</h1>
      <p class="sub">Veterinarios al instante, su historia clínica siempre contigo y recordatorios que no fallan. Porque cuando se trata de quien más amas, la tranquilidad no debería ser un lujo.</p>
      <div class="ctas">
        <a href="#descargar" class="btn btn-primary"><i data-lucide="download"></i>Descargar App</a>
        <a href="#how" class="btn btn-secondary">Ver cómo funciona<i data-lucide="arrow-right"></i></a>
      </div>
      <div class="stores">
        <a href="<?php echo esc_url( $gplay_url ); ?>" target="_blank" rel="noopener" class="store-btn">
          <?php echo $gplay_svg; ?>
          <span><span class="small">Disponible en</span><br><span class="big">Google Play</span></span>
        </a>
        <a href="#app-store" class="store-btn store-btn-soon">
          <?php echo $apple_svg; ?>
          <span><span class="small">Próximamente en</span><br><span class="big">Apple</span></span>
        </a>
      </div>
      <div class="qr">
        <img class="qr-img" src="<?php echo esc_url( $img_dir . '/qr-googleplay.png' ); ?>" alt="Escanea para descargar PlusKotas en Google Play">
        <div>
          <div style="font-weight:700;font-size:14px;color:var(--ink)">Escanea para descargar</div>
          <div style="font-size:12px;color:var(--muted);margin-top:4px">Apunta tu cámara al código</div>
        </div>
      </div>
    </div>

    <div class="phone-stage">
      <div class="blob blob-3"></div>
      <div class="float-card fc-1"><i data-lucide="check-circle"></i>Cita confirmada</div>
      <div class="float-card fc-2"><i data-lucide="syringe"></i>Vacuna en 3 días</div>
      <div class="float-card fc-3"><i data-lucide="badge-check"></i>Dr. verificado</div>
      <div class="float-card fc-4"><i data-lucide="bell"></i>Recordatorio creado</div>
      <div class="phone">
        <div class="phone-screen">
          <div class="phone-greeting"><span>Hola</span>John 👋</div>
          <div class="mini-card" style="background:linear-gradient(135deg,var(--deep),var(--teal));color:#fff;border:0">
            <div class="mini-row">
              <div style="width:38px;height:38px;border-radius:999px;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center"><i data-lucide="video" style="width:18px;height:18px;color:#fff"></i></div>
              <div style="flex:1"><div style="font-weight:700;font-size:13px">Veterinarios en línea</div><div style="font-size:11px;opacity:0.8">Habla con un vet ahora</div></div>
            </div>
          </div>
          <div class="mini-card">
            <div class="mini-row">
              <div class="mini-avatar">L</div>
              <div style="flex:1">
                <div style="display:flex;justify-content:space-between">
                  <div style="font-weight:700;font-size:13px">Luna</div>
                  <span class="pill pill-success">Confirmada</span>
                </div>
                <div style="font-size:11px;color:var(--muted);margin-top:2px">Hoy 14:30 · Dra. María</div>
              </div>
            </div>
          </div>
          <div class="mini-card">
            <div class="mini-row">
              <div class="mini-avatar" style="background:#FFEFC9">M</div>
              <div style="flex:1"><div style="font-weight:700;font-size:13px">Milo</div><div style="font-size:11px;color:var(--muted)">Antirrábica · 15 Mar</div></div>
              <span class="pill pill-yellow">Pronto</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- TRUST STRIP -->
<section class="trust">
  <div class="wrap">
    <div class="trust-row">
      <div><i data-lucide="badge-check"></i>Veterinarios verificados</div>
      <div><i data-lucide="folder-heart"></i>Historial médico digital</div>
      <div><i data-lucide="bell"></i>Recordatorios inteligentes</div>
      <div><i data-lucide="book-open"></i>Artículos de veterinarios</div>
    </div>
  </div>
</section>

<!-- PROBLEM -->
<section>
  <div class="wrap">
    <div class="problem-card">
      <h2>Cuidar a tu mascota no debería ser complicado</h2>
      <p>Entre citas, vacunas, medicamentos, documentos y dudas de salud, es fácil perder información importante o no saber qué hacer cuando algo te preocupa. PlusKotas te ayuda a organizar el cuidado de tu mascota y acceder a apoyo veterinario cuando lo necesitas.</p>
      <div class="bubbles">
        <span class="bubble">"No encuentro el carnet de vacunas"</span>
        <span class="bubble">"Se me olvidó la desparasitación"</span>
        <span class="bubble">"No sé si debo ir al veterinario"</span>
        <span class="bubble">"Tengo la información en mil lugares"</span>
        <span class="bubble">"Busco en internet y termino más preocupado"</span>
      </div>
    </div>
  </div>
</section>

<!-- BENEFITS / FUNCTIONS -->
<section id="benefits">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Funciones</span>
      <h2 style="margin-top:14px">Todo lo que necesitas para cuidar mejor a tu mascota</h2>
      <p>Una app simple para resolver las dudas, citas y recordatorios del día a día.</p>
    </div>
    <div class="bento">
      <div class="feat-card hero-feat">
        <div class="feat-icon"><i data-lucide="stethoscope"></i></div>
        <span class="pill" style="background:rgba(255,255,255,0.15);color:#fff;align-self:flex-start"><i data-lucide="badge-check" style="width:12px;height:12px"></i>Veterinarios verificados</span>
        <h3>Videollamadas con Veterinarios</h3>
        <p>Habla con veterinarios verificados desde donde estés y recibe orientación profesional para cuidar la salud de tu mascota de forma rápida, cómoda y segura.</p>
        <ul class="hero-feat-list">
          <li><i data-lucide="video"></i>Videollamadas en HD</li>
          <li><i data-lucide="clock"></i>Disponibles todos los días</li>
          <li><i data-lucide="file-text"></i>Receta digital</li>
          <li><i data-lucide="heart-pulse"></i>Cita de Seguimiento incluida</li>
        </ul>
        <div class="hero-feat-preview">
          <div class="avatar">A</div>
          <div style="line-height:1.3">
            <div style="font-weight:700;font-size:14px">Dra. Amaro</div>
            <div style="font-size:12px;opacity:0.85">Medicina general · 4.9 ★</div>
          </div>
          <span class="live"><span class="dot"></span>En línea</span>
        </div>
        <div style="margin-top:auto;padding-top:22px">
          <a href="#vets-deep" class="feat-link" style="color:#FFBF3B;display:inline-flex;height:20px;gap:6px;margin:1px 0px 0px">Conocer citas en línea<i data-lucide="arrow-right" style="width:14px;height:14px"></i></a>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:20px">
        <div class="feat-card">
          <div class="feat-icon"><i data-lucide="folder-heart"></i></div>
          <h3>Historial médico digital</h3>
          <p>Guarda vacunas, documentos, imágenes, diagnósticos y datos importantes de tu mascota en un solo lugar, siempre disponible cuando lo necesites.</p>
        </div>
        <div class="feat-card">
          <div class="feat-icon"><i data-lucide="bell"></i></div>
          <h3>Recordatorios y calendario</h3>
          <p>Nunca olvides una vacuna, desparasitación, medicina, cita veterinaria o evento importante. PlusKotas te ayuda a mantener el cuidado de tu mascota al día.</p>
        </div>
      </div>
    </div>
    <div class="feat-card" style="margin-top:20px">
      <div class="feat-icon"><i data-lucide="book-open"></i></div>
      <h3>Información confiable</h3>
      <p>Accede a artículos y consejos escritos por veterinarios para aprender más sobre salud, bienestar, prevención y cuidado diario de tu mascota.</p>
    </div>
    <div style="text-align:center;margin-top:40px"><a href="#descargar" class="btn btn-primary"><i data-lucide="download"></i>Descargar PlusKotas</a></div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section id="how" style="background:var(--mint)">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Cómo funciona</span>
      <h2 style="margin-top:14px">Así funciona PlusKotas</h2>
      <p>Empieza en minutos y mantén el cuidado de tu mascota organizado desde tu celular.</p>
    </div>
    <div class="steps">
      <div class="step">
        <div class="step-num">1</div>
        <h3>Crea el perfil de tu mascota</h3>
        <p style="margin-top:10px">Agrega sus datos, fotos, documentos e historial médico.</p>
      </div>
      <div class="step">
        <div class="step-num">2</div>
        <h3>Agenda una cita o configura recordatorios</h3>
        <p style="margin-top:10px">Habla con un veterinario en línea o programa alertas para eventos importantes.</p>
      </div>
      <div class="step">
        <div class="step-num">3</div>
        <h3>Mantén su salud organizada</h3>
        <p style="margin-top:10px">Consulta su información cuando la necesites y recibe apoyo confiable desde la app.</p>
      </div>
    </div>
  </div>
</section>

<!-- VETS DEEP DIVE -->
<section id="vets-deep">
  <div class="wrap deep">
    <div>
      <span class="eyebrow">Veterinarios en línea</span>
      <h2 style="margin-top:14px">Habla con un veterinario sin salir de casa</h2>
      <p style="margin-top:18px;font-size:17px">PlusKotas te permite recibir orientación profesional por videollamada para dudas de salud, seguimiento, cuidado preventivo, comportamiento, nutrición y síntomas que puedan evaluarse de forma virtual.</p>
      <ul>
        <li><i data-lucide="check"></i>Veterinarios verificados</li>
        <li><i data-lucide="check"></i>Videollamadas desde la app</li>
        <li><i data-lucide="check"></i>Orientación profesional</li>
        <li><i data-lucide="check"></i>Seguimiento y reportes</li>
        <li><i data-lucide="check"></i>Información vinculada al perfil de tu mascota</li>
      </ul>
      <a href="#descargar" class="btn btn-primary"><i data-lucide="calendar-plus"></i>Agendar desde la app</a>
      <div class="disclaimer">
        <i data-lucide="info"></i>
        <div>Las consultas en línea son ideales para orientación y seguimiento. En caso de emergencia, te recomendamos acudir a una clínica veterinaria presencial.</div>
      </div>
    </div>
    <div class="visual">
      <div class="blob blob-1" style="opacity:0.3"></div>
      <div class="float-card" style="position:relative;animation:none"><i data-lucide="badge-check" style="color:var(--teal)"></i>Verificado</div>
      <img src="<?php echo esc_url( $img_dir . '/screens/web-perfil-vet.png' ); ?>" alt="Perfil de veterinario" style="border-radius:18px;box-shadow:var(--shadow-floating);max-width:480px;width:100%;position:absolute">
    </div>
  </div>
</section>

<!-- MEDICAL HISTORY -->
<section style="background:var(--mint-2)">
  <div class="wrap deep">
    <div class="visual">
      <img src="<?php echo esc_url( $img_dir . '/screens/mobile-perfil-usuario.png' ); ?>" alt="Historial médico de mascota" style="border-radius:32px;box-shadow:var(--shadow-floating);max-width:300px;height:565px">
    </div>
    <div>
      <span class="eyebrow">Historial médico</span>
      <h2 style="margin-top:14px">El historial de tu mascota, siempre contigo</h2>
      <p style="margin-top:18px;font-size:17px">Olvídate de buscar carnets, fotos, recetas o documentos en diferentes lugares. Con PlusKotas puedes guardar la información importante de tu mascota y consultarla cuando la necesites.</p>
      <div class="chips">
        <span class="chip">Vacunas</span>
        <span class="chip">Desparasitaciones</span>
        <span class="chip">Medicamentos</span>
        <span class="chip">Recetas</span>
        <span class="chip">Documentos</span>
        <span class="chip">Imágenes</span>
        <span class="chip">Reportes</span>
        <span class="chip">Condiciones Médicas</span>
      </div>
      <a href="#descargar" class="btn btn-primary" style="margin-top:24px"><i data-lucide="folder-heart"></i>Organizar historial médico</a>
    </div>
  </div>
</section>

<!-- REMINDERS -->
<section>
  <div class="wrap deep">
    <div>
      <span class="eyebrow">Recordatorios</span>
      <h2 style="margin-top:14px">Nunca olvides una vacuna, medicina o cita importante</h2>
      <p style="margin-top:18px;font-size:17px">Configura recordatorios para los eventos clave del cuidado de tu mascota y recibe alertas cuando se acerque la fecha.</p>
      <div class="chips">
        <span class="chip">Vacunas</span>
        <span class="chip">Medicamentos</span>
        <span class="chip">Desparasitación</span>
        <span class="chip">Citas</span>
        <span class="chip">Cumpleaños</span>
        <span class="chip">Grooming</span>
        <span class="chip">Alimentación</span>
      </div>
      <a href="#descargar" class="btn btn-primary" style="margin-top:24px"><i data-lucide="bell"></i>Crear recordatorios</a>
    </div>
    <div class="visual">
      <div class="blob blob-2" style="opacity:0.3"></div>
      <div class="phone" style="width:260px;height:520px">
        <div class="phone-screen" style="padding:64px 14px 14px;display:flex;flex-direction:column;gap:10px;background:linear-gradient(180deg,var(--mint-2),#fff 40%)">
          <div style="display:flex;align-items:center;justify-content:space-between;padding:0 4px">
            <div>
              <div style="font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:0.06em;font-weight:700">Próximos</div>
              <div style="font-weight:800;font-size:16px;color:var(--ink);letter-spacing:-0.01em">Esta semana</div>
            </div>
            <div style="width:32px;height:32px;border-radius:999px;background:var(--deep);display:flex;align-items:center;justify-content:center;box-shadow:var(--shadow-card)"><i data-lucide="plus" style="color:#fff;width:16px;height:16px"></i></div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;background:#fff;border-radius:12px;padding:10px;box-shadow:var(--shadow-card)">
            <div style="width:32px;height:32px;border-radius:10px;background:#FFF1D6;display:flex;align-items:center;justify-content:center"><i data-lucide="pill" style="color:#C77B00;width:15px;height:15px"></i></div>
            <div style="flex:1;line-height:1.25">
              <div style="font-weight:700;font-size:11.5px;color:var(--ink)">Antiparasitario</div>
              <div style="font-size:10px;color:var(--muted)">Hoy · 8:00 pm</div>
            </div>
            <div style="font-size:10px;color:var(--muted);font-weight:700">Hoy</div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;background:#fff;border-radius:12px;padding:10px;box-shadow:var(--shadow-card)">
            <div style="width:32px;height:32px;border-radius:10px;background:#E6F7F1;display:flex;align-items:center;justify-content:center"><i data-lucide="scissors" style="color:var(--deep);width:15px;height:15px"></i></div>
            <div style="flex:1;line-height:1.25">
              <div style="font-weight:700;font-size:11.5px;color:var(--ink)">Grooming de Milo</div>
              <div style="font-size:10px;color:var(--muted)">Mar 12 may · 4:00 pm</div>
            </div>
            <div style="font-size:10px;color:var(--muted);font-weight:700">5d</div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;background:#fff;border-radius:12px;padding:10px;box-shadow:var(--shadow-card);animation:floaty 2.4s ease-in-out infinite">
            <div style="width:32px;height:32px;border-radius:10px;background:#FFE9E1;display:flex;align-items:center;justify-content:center"><i data-lucide="cake" style="color:#D9531E;width:15px;height:15px"></i></div>
            <div style="flex:1;line-height:1.25">
              <div style="font-weight:700;font-size:11.5px;color:var(--ink)">Cumple de Luna 🎉</div>
              <div style="font-size:10px;color:var(--muted)">Vie 22 may</div>
            </div>
            <div style="font-size:10px;color:var(--muted);font-weight:700">15d</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ARTICLES -->
<section style="background:var(--aqua)">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Información</span>
      <h2 style="margin-top:14px">Información veterinaria confiable, sin búsquedas interminables</h2>
      <p>Accede a artículos escritos por veterinarios sobre salud preventiva, síntomas comunes, vacunas, nutrición, comportamiento, cuidado diario y más.</p>
    </div>

    <?php
    $recent_posts = get_posts( [ 'numberposts' => 3, 'post_status' => 'publish' ] );
    $art_gradients = [
      'linear-gradient(135deg,var(--teal),var(--deep))',
      'linear-gradient(135deg,var(--coral),#FFA8A8)',
      'linear-gradient(135deg,var(--yellow),#FFDF8C)',
    ];
    $art_icons = [ 'syringe', 'heart', 'bone' ];
    if ( $recent_posts ) :
    ?>
    <div class="articles">
      <?php foreach ( $recent_posts as $idx => $post ) :
        $cats  = get_the_category( $post->ID );
        $cat   = $cats ? esc_html( $cats[0]->name ) : 'Artículo';
        $mins  = pluskotas_reading_time( $post->ID );
        $thumb = get_the_post_thumbnail( $post->ID, 'medium' );
        $grad  = $art_gradients[ $idx % 3 ];
        $icon  = $art_icons[ $idx % 3 ];
      ?>
      <article class="art-card">
        <?php if ( $thumb ) : ?>
          <div class="art-img" style="height:180px;overflow:hidden"><?php echo $thumb; ?></div>
        <?php else : ?>
          <div class="art-img" style="background:<?php echo esc_attr( $grad ); ?>"><i data-lucide="<?php echo esc_attr( $icon ); ?>"></i></div>
        <?php endif; ?>
        <div class="art-body">
          <span class="art-cat"><?php echo $cat; ?></span>
          <h3><?php echo esc_html( $post->post_title ); ?></h3>
          <div class="art-meta">Lectura de <?php echo $mins; ?> min · Revisado por veterinario</div>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
    <?php else : ?>
    <div class="articles">
      <article class="art-card"><div class="art-img" style="background:linear-gradient(135deg,var(--teal),var(--deep))"><i data-lucide="syringe"></i></div><div class="art-body"><span class="art-cat">Salud preventiva</span><h3>Vacunas esenciales para perros y gatos</h3><div class="art-meta">Lectura de 5 min · Revisado por veterinario</div></div></article>
      <article class="art-card"><div class="art-img" style="background:linear-gradient(135deg,var(--coral),#FFA8A8)"><i data-lucide="heart"></i></div><div class="art-body"><span class="art-cat">Comportamiento</span><h3>Señales de estrés que no deberías ignorar</h3><div class="art-meta">Lectura de 4 min · Revisado por veterinario</div></div></article>
      <article class="art-card"><div class="art-img" style="background:linear-gradient(135deg,var(--yellow),#FFDF8C)"><i data-lucide="bone"></i></div><div class="art-body"><span class="art-cat">Nutrición</span><h3>Cómo mejorar la alimentación diaria de tu mascota</h3><div class="art-meta">Lectura de 6 min · Revisado por veterinario</div></div></article>
    </div>
    <?php endif; ?>

    <div style="text-align:center;margin-top:40px;display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
      <a href="<?php echo esc_url( get_permalink( get_page_by_path( 'articulos' ) ) ); ?>" class="btn btn-secondary">Leer artículos</a>
      <a href="#descargar" class="btn btn-primary"><i data-lucide="download"></i>Descargar app</a>
    </div>
  </div>
</section>

<!-- PREMIUM -->
<section>
  <div class="wrap">
    <div class="premium-panel">
      <div class="premium-grid">
        <div>
          <span class="premium-badge"><i data-lucide="crown" style="width:14px;height:14px"></i>Premium</span>
          <h2 style="margin-top:14px">6 meses de PlusKotas Premium gratis</h2>
          <p style="margin-top:18px;font-size:17px">Regístrate durante el primer mes de lanzamiento y disfruta PlusKotas Premium gratis durante 6 meses.</p>
          <ul style="list-style:none;padding:0;margin:24px 0">
            <li style="display:flex;gap:8px;padding:6px 0;font-weight:500;color:var(--ink)"><i data-lucide="check" style="width:18px;height:18px;color:var(--teal)"></i>Sin comisión de servicio en citas veterinarias</li>
            <li style="display:flex;gap:8px;padding:6px 0;font-weight:500;color:var(--ink)"><i data-lucide="check" style="width:18px;height:18px;color:var(--teal)"></i>Recordatorios desbloqueados</li>
            <li style="display:flex;gap:8px;padding:6px 0;font-weight:500;color:var(--ink)"><i data-lucide="check" style="width:18px;height:18px;color:var(--teal)"></i>Hasta 10 perfiles de mascotas</li>
            <li style="display:flex;gap:8px;padding:6px 0;font-weight:500;color:var(--ink)"><i data-lucide="check" style="width:18px;height:18px;color:var(--teal)"></i>Sin anuncios</li>
            <li style="display:flex;gap:8px;padding:6px 0;font-weight:500;color:var(--ink)"><i data-lucide="check" style="width:18px;height:18px;color:var(--teal)"></i>Acceso prioritario a futuras funciones</li>
          </ul>
        </div>
        <div class="pricing-card">
          <span class="premium-badge"><i data-lucide="sparkles" style="width:14px;height:14px"></i>Premium</span>
          <div style="margin-top:18px"><div class="price">$4.99<span> / mes</span></div></div>
          <div style="font-size:14px;opacity:0.8;margin-top:4px">o $44.99 / año</div>
          <div style="background:rgba(255,255,255,0.1);border-radius:12px;padding:10px 14px;margin-top:18px;font-size:13px">✨ Normalmente 1 mes de prueba gratis</div>
          <a href="#descargar" class="btn btn-primary" style="margin-top:18px;width:100%;justify-content:center">Descargar y reclamar promoción</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- USE CASES -->
<section style="background:var(--mint)">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">Casos de uso</span>
      <h2 style="margin-top:14px">¿Cuándo usar PlusKotas?</h2>
    </div>
    <div class="uses">
      <div class="use-card"><i data-lucide="help-circle"></i><div>Cuando quieres información confiable de veterinarios</div></div>
      <div class="use-card"><i data-lucide="repeat"></i><div>Cuando necesitas una segunda opinión</div></div>
      <div class="use-card"><i data-lucide="folder-heart"></i><div>Cuando quieres organizar vacunas y documentos</div></div>
      <div class="use-card"><i data-lucide="pill"></i><div>Cuando necesitas recordar medicamentos</div></div>
      <div class="use-card"><i data-lucide="users"></i><div>Cuando tienes varias mascotas y necesitas recordar todo sobre ellas</div></div>
      <div class="use-card"><i data-lucide="book-open"></i><div>Cuando quieres aprender más sobre el cuidado de tu mascota</div></div>
    </div>
  </div>
</section>

<!-- TRUST BLOCK -->
<section>
  <div class="wrap">
    <div class="trust-block">
      <div class="section-head">
        <span class="eyebrow" style="color:var(--yellow)">Responsabilidad</span>
        <h2 style="margin-top:14px">Diseñado para cuidar con responsabilidad</h2>
        <p>PlusKotas combina tecnología, organización y apoyo veterinario para ayudarte a tomar mejores decisiones sobre el cuidado de tu mascota.</p>
      </div>
      <div class="trust-cards">
        <div class="trust-c"><i data-lucide="badge-check"></i><h3>Veterinarios verificados</h3><p>Los profesionales que atienden en PlusKotas pasan por un proceso de revisión.</p></div>
        <div class="trust-c"><i data-lucide="book-open"></i><h3>Información confiable</h3><p>Los contenidos son escritos por veterinarios.</p></div>
        <div class="trust-c"><i data-lucide="alert-triangle"></i><h3>Límites claros</h3><p>Las consultas virtuales son útiles para orientación pero no sustituyen atención presencial en emergencias.</p></div>
        <div class="trust-c"><i data-lucide="folder-heart"></i><h3>Datos organizados</h3><p>Mantén la información importante de tu mascota en un solo lugar.</p></div>
      </div>
    </div>
  </div>
</section>

<!-- FOR VETS -->
<section>
  <div class="wrap">
    <div class="for-vets">
      <div class="for-vets-grid">
        <div>
          <span class="eyebrow">Para veterinarios</span>
          <h2 style="margin-top:14px">¿Eres veterinario? Únete a PlusKotas</h2>
          <p style="margin-top:18px;font-size:17px">Atiende consultas en línea, maneja tu disponibilidad y conecta con dueños de mascotas que buscan orientación profesional confiable.</p>
          <a href="<?php echo esc_url( get_permalink( get_page_by_path( 'veterinarios' ) ) ); ?>" class="btn btn-primary" style="margin-top:24px"><i data-lucide="stethoscope"></i>Conocer PlusKotas para veterinarios</a>
        </div>
        <div class="visual">
          <img src="<?php echo esc_url( $img_dir . '/screens/web-perfil-vet.png' ); ?>" alt="Portal para veterinarios" style="border-radius:18px;box-shadow:var(--shadow-floating);max-width:100%;">
        </div>
      </div>
    </div>
  </div>
</section>

<!-- FAQ -->
<section style="background:var(--aqua)">
  <div class="wrap">
    <div class="section-head">
      <span class="eyebrow">FAQ</span>
      <h2 style="margin-top:14px">Preguntas frecuentes</h2>
    </div>
    <div class="faq-list">
      <div class="faq-item"><div class="faq-q">¿Qué es PlusKotas?</div><div class="faq-a"><p>PlusKotas es una plataforma digital que conecta a dueños de mascotas con veterinarios certificados de forma rápida, segura y confiable. Además, puedes guardar el historial médico de tu (s) mascota (as) y te ayuda con recordatorios para medicinas, vacunas, desparasitaciones y más. También puedes acceder a artículos educativos e informativos, escritos por veterinarios.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿PlusKotas reemplaza al veterinario presencial?</div><div class="faq-a"><p>No. PlusKotas complementa la atención presencial. La telemedicina permite resolver dudas, dar seguimiento y orientar de forma inmediata, pero los procedimientos físicos y diagnósticos que requieren contacto directo siguen siendo responsabilidad del veterinario en clínica.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Las consultas online son con veterinarios certificados?</div><div class="faq-a"><p>Sí. Todas las consultas online son atendidas por veterinarios titulados y verificados en su país, con licencia para ejercer y varios años de experiencia clínica.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Puedo tener más de una mascota en mi perfil?</div><div class="faq-a"><p>Sí. Plan Gratis: 2 perfiles. Plan Premium: hasta 10 perfiles de mascotas.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Mis datos y los de mi mascota están seguros?</div><div class="faq-a"><p>Sí. PlusKotas protege la información personal y clínica de cada usuario y su mascota mediante sistemas de seguridad y almacenamiento confiable.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Cuánto cuesta la suscripción?</div><div class="faq-a"><p>La suscripción Premium de PlusKotas tiene un mes gratis de prueba y posteriormente cuesta $4.99 al mes o $44.99 al año.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿En qué lugares funciona PlusKotas?</div><div class="faq-a"><p>Puedes acceder a la app y realizar consultas de teleasesoría desde donde quieras. Los veterinarios solo pueden emitir recetas en el país donde sus licencias están validadas y vigentes.</p></div></div>
    </div>
    <div style="text-align:center;margin-top:36px">
      <a href="<?php echo esc_url( get_permalink( get_page_by_path( 'preguntas-frecuentes' ) ) ); ?>" class="btn btn-secondary">Ver todas las preguntas <i data-lucide="arrow-right"></i></a>
    </div>
  </div>
</section>

<!-- FINAL CTA -->
<section id="descargar">
  <div class="wrap">
    <div class="final">
      <div class="final-grid">
        <div>
          <h2>Empieza hoy a cuidar mejor la salud de tu mascota</h2>
          <p style="margin-top:18px;font-size:17px">Descarga PlusKotas durante el primer mes y disfruta de 6 meses gratis.</p>
          <div class="stores">
            <a href="<?php echo esc_url( $gplay_url ); ?>" target="_blank" rel="noopener" class="store-btn">
              <?php echo $gplay_svg; ?>
              <span><span class="small">Descargar en</span><br><span class="big">Google Play</span></span>
            </a>
            <a href="#app-store" class="store-btn store-btn-soon">
              <?php echo $apple_svg; ?>
              <span><span class="small">Próximamente en</span><br><span class="big">Apple</span></span>
            </a>
          </div>
        </div>
        <div class="qr" style="background:rgba(255,255,255,0.1);border-color:rgba(255,255,255,0.2)">
          <img class="qr-img" src="<?php echo esc_url( $img_dir . '/qr-googleplay.png' ); ?>" alt="Escanea para descargar PlusKotas en Google Play">
          <div>
            <div style="font-weight:700;font-size:14px;color:#fff">Escanea el código QR</div>
            <div style="font-size:12px;color:rgba(255,255,255,0.7);margin-top:4px">para descargar la app</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- STICKY MOBILE CTA -->
<div class="mobile-cta">
  <a href="#descargar" class="btn btn-primary"><i data-lucide="download"></i>Descargar App</a>
</div>

<?php get_footer(); ?>
