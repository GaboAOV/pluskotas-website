document.addEventListener('DOMContentLoaded', function () {
  // Initialize Lucide icons
  if (typeof lucide !== 'undefined') {
    lucide.createIcons();
  }

  // FAQ accordion (static FAQ items in templates)
  document.querySelectorAll('.faq-q').forEach(function (q) {
    if (q.dataset.faqBound) return;
    q.dataset.faqBound = '1';
    q.addEventListener('click', function () {
      q.parentElement.classList.toggle('open');
    });
  });

  // Dynamic FAQ (Preguntas Frecuentes page)
  var faqDataEl = document.getElementById('faq-data');
  var listEl    = document.getElementById('faq-list');
  var toolbar   = document.getElementById('faq-toolbar');
  var searchEl  = document.getElementById('faq-search');
  var empty     = document.getElementById('faq-empty');
  var countEl   = document.getElementById('faq-count');

  if (!faqDataEl || !listEl) return;

  var DATA = JSON.parse(faqDataEl.textContent);
  var activeCat = 'all';

  var catOrder = [
    { id: 'all',          label: 'Todas' },
    { id: 'general',      label: 'Sobre PlusKotas' },
    { id: 'cuenta',       label: 'Cuenta y registro' },
    { id: 'mascotas',     label: 'Mascotas e historial' },
    { id: 'telemedicina', label: 'Telemedicina' },
    { id: 'recordatorios',label: 'Recordatorios' },
    { id: 'premium',      label: 'Pagos y Premium' },
    { id: 'privacidad',   label: 'Privacidad' },
    { id: 'cobertura',    label: 'Disponibilidad' },
    { id: 'contenido',    label: 'Contenido' },
    { id: 'soporte',      label: 'Soporte' },
    { id: 'vet-pros',     label: 'Para Veterinarios' },
  ];

  function renderAnswer(lines) {
    var out = [];
    var listBuf = null;
    var paraBuf = [];
    function flushPara() {
      if (paraBuf.length) { out.push('<p>' + paraBuf.join(' ') + '</p>'); paraBuf = []; }
    }
    function flushList() {
      if (listBuf) { out.push('<ul>' + listBuf.map(function (li) { return '<li>' + li + '</li>'; }).join('') + '</ul>'); listBuf = null; }
    }
    lines.forEach(function (raw) {
      var trimmed = raw.trim();
      if (!trimmed) { flushPara(); return; }
      var html = trimmed.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
      if (trimmed.startsWith('- ')) {
        flushPara();
        if (!listBuf) listBuf = [];
        listBuf.push(html.slice(2));
      } else {
        flushList();
        paraBuf.push(html);
      }
    });
    flushPara();
    flushList();
    return out.join('');
  }

  // Build category chips
  var counts = {};
  DATA.forEach(function (d) { counts[d.cat] = (counts[d.cat] || 0) + 1; });
  catOrder.forEach(function (c) {
    var n = c.id === 'all' ? DATA.length : (counts[c.id] || 0);
    if (c.id !== 'all' && n === 0) return;
    var btn = document.createElement('button');
    btn.className = 'faq-chip' + (c.id === 'all' ? ' active' : '');
    btn.dataset.cat = c.id;
    btn.innerHTML = c.label + ' <span class="count">' + n + '</span>';
    btn.addEventListener('click', function () {
      document.querySelectorAll('.faq-chip').forEach(function (x) { x.classList.remove('active'); });
      btn.classList.add('active');
      activeCat = c.id;
      applyFilter();
      var top = searchEl.getBoundingClientRect().top + window.scrollY - 120;
      window.scrollTo({ top: top, behavior: 'smooth' });
    });
    toolbar.appendChild(btn);
  });

  // Build FAQ items
  DATA.forEach(function (item, idx) {
    var div = document.createElement('div');
    div.className = 'faq-item';
    div.dataset.cat = item.cat;
    div.dataset.idx = idx;
    div.innerHTML =
      '<div class="faq-q">' +
        '<span class="faq-q-text">' +
          '<span class="faq-cat-label">' + item.catLabel + '</span><br>' +
          item.q +
        '</span>' +
      '</div>' +
      '<div class="faq-a">' + renderAnswer(item.a) + '</div>';
    div.querySelector('.faq-q').addEventListener('click', function () { div.classList.toggle('open'); });
    listEl.appendChild(div);
  });

  // Deep-link: ?cat=premium
  var params  = new URLSearchParams(location.search);
  var initCat = params.get('cat');
  if (initCat) {
    var chip = document.querySelector('.faq-chip[data-cat="' + initCat + '"]');
    if (chip) chip.click();
  }

  function applyFilter() {
    var term = searchEl ? searchEl.value.trim().toLowerCase() : '';
    var visible = 0;
    document.querySelectorAll('#faq-list .faq-item').forEach(function (it) {
      var matchesCat  = activeCat === 'all' || it.dataset.cat === activeCat;
      var matchesText = !term || it.textContent.toLowerCase().includes(term);
      var show = matchesCat && matchesText;
      it.style.display = show ? '' : 'none';
      if (show) visible++;
    });
    if (empty)   empty.classList.toggle('show', visible === 0);
    if (countEl) countEl.textContent = visible === 0 ? '' : visible + ' ' + (visible === 1 ? 'pregunta' : 'preguntas');
  }

  if (searchEl) searchEl.addEventListener('input', applyFilter);
  applyFilter();
});
