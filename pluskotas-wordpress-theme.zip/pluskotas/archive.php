<?php get_header(); ?>

<section class="page-hero">
  <span class="eyebrow">Centro de contenido</span>
  <h1>Consejos veterinarios para cuidar mejor a tu mascota</h1>
  <p>Artículos escritos o revisados por veterinarios sobre salud, prevención, comportamiento, nutrición y cuidado diario.</p>
</section>

<section style="padding-top:0">
  <div class="wrap">

    <?php
    // Category filter chips
    $categories = get_categories( [ 'hide_empty' => true ] );
    $active_cat = get_query_var( 'cat' ) ? absint( get_query_var( 'cat' ) ) : 0;
    ?>

    <?php if ( $categories ) : ?>
    <div class="cats" id="cat-filter">
      <a href="<?php echo esc_url( get_post_type_archive_link( 'post' ) ); ?>" class="cat<?php echo ( ! $active_cat ? ' active' : '' ); ?>">Todos</a>
      <?php foreach ( $categories as $cat ) : ?>
        <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="cat<?php echo ( $active_cat === $cat->term_id ? ' active' : '' ); ?>">
          <?php echo esc_html( $cat->name ); ?>
        </a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="art-grid">
      <?php
      $art_gradients = [
        'linear-gradient(135deg,var(--teal),var(--deep))',
        'linear-gradient(135deg,var(--coral),#FFA8A8)',
        'linear-gradient(135deg,var(--yellow),#FFDF8C)',
        'linear-gradient(135deg,var(--deep),var(--teal))',
        'linear-gradient(135deg,#00AA83,#5DD4B0)',
        'linear-gradient(135deg,#FF6B6B,#FFBF3B)',
      ];
      $art_icons = [ 'syringe', 'alert-circle', 'heart', 'folder-heart', 'bug', 'bone' ];
      $idx = 0;

      if ( have_posts() ) :
        while ( have_posts() ) : the_post();
          $cats  = get_the_category();
          $cat   = $cats ? esc_html( $cats[0]->name ) : '';
          $mins  = pluskotas_reading_time();
          $thumb = get_the_post_thumbnail( null, 'medium_large' );
          $grad  = $art_gradients[ $idx % 6 ];
          $icon  = $art_icons[ $idx % 6 ];
          $idx++;
      ?>
      <article class="art-card" onclick="window.location='<?php the_permalink(); ?>'" style="cursor:pointer">
        <?php if ( $thumb ) : ?>
          <div class="art-img" style="height:180px;overflow:hidden;background:#eee"><?php echo $thumb; ?></div>
        <?php else : ?>
          <div class="art-img" style="background:<?php echo esc_attr( $grad ); ?>">
            <i data-lucide="<?php echo esc_attr( $icon ); ?>"></i>
          </div>
        <?php endif; ?>
        <div class="art-body">
          <?php if ( $cat ) : ?><span class="art-cat"><?php echo $cat; ?></span><?php endif; ?>
          <h3><?php the_title(); ?></h3>
          <p><?php echo esc_html( get_the_excerpt() ); ?></p>
          <div class="art-meta"><i data-lucide="clock"></i><?php echo $mins; ?> min · Revisado por veterinario</div>
        </div>
      </article>
      <?php
        endwhile;
      else :
      ?>
        <p style="grid-column:1/-1;text-align:center;color:var(--muted);padding:40px 0">No hay artículos publicados todavía.</p>
      <?php endif; ?>
    </div>

    <?php if ( $GLOBALS['wp_query']->max_num_pages > 1 ) : ?>
    <div style="text-align:center;margin-top:48px;display:flex;gap:10px;justify-content:center">
      <?php if ( get_previous_posts_link() ) : ?>
        <a href="<?php echo esc_url( get_previous_posts_page_link() ); ?>" class="btn btn-secondary"><i data-lucide="arrow-left"></i>Anteriores</a>
      <?php endif; ?>
      <?php if ( get_next_posts_link() ) : ?>
        <a href="<?php echo esc_url( get_next_posts_page_link() ); ?>" class="btn btn-secondary">Siguientes<i data-lucide="arrow-right"></i></a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

  </div>
</section>

<section id="descargar" style="background:var(--mint)">
  <div class="wrap">
    <div class="final">
      <div style="text-align:center;max-width:720px;margin:0 auto;position:relative;z-index:2">
        <h2>¿Tienes una duda sobre tu mascota?</h2>
        <p style="margin-top:18px;font-size:17px">Agenda una consulta en línea con un veterinario verificado desde PlusKotas.</p>
        <a href="https://play.google.com/store/apps/details?id=com.avantelogic.pluskotas&pcampaignid=web_share" target="_blank" rel="noopener" class="btn btn-primary" style="background:var(--yellow);color:var(--ink);margin-top:24px"><i data-lucide="download"></i>Descargar app</a>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
