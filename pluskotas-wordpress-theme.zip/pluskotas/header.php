<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<?php
$is_vet_page    = is_page_template( 'template-veterinarios.php' );
$is_front       = is_front_page();
$img_dir        = get_template_directory_uri() . '/assets/images';
$download_href  = $is_front ? '#descargar' : esc_url( home_url( '/#descargar' ) );
?>

<header class="site">
  <div class="wrap nav">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo">
      <img src="<?php echo esc_url( $img_dir . '/logo-full.png' ); ?>" alt="+kotas">
    </a>

    <nav aria-label="Primary">
      <ul>
        <li><a href="<?php echo esc_url( home_url( '/#how' ) ); ?>"<?php echo ( $is_front ? '' : '' ); ?>>Cómo funciona</a></li>
        <li><a href="<?php echo esc_url( home_url( '/#benefits' ) ); ?>">Funciones</a></li>
        <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'premium' ) ) ); ?>"<?php echo ( is_page_template( 'template-premium.php' ) ? ' style="color:var(--teal)"' : '' ); ?>>Premium</a></li>
        <li><a href="<?php echo esc_url( get_post_type_archive_link( 'post' ) ); ?>"<?php echo ( is_home() || is_archive() ? ' style="color:var(--teal)"' : '' ); ?>>Artículos</a></li>
        <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'veterinarios' ) ) ); ?>"<?php echo ( $is_vet_page ? ' style="color:var(--teal)"' : '' ); ?>>Para Veterinarios</a></li>
      </ul>
    </nav>

    <div class="nav-actions">
      <div class="nav-socials">
        <a href="https://www.facebook.com/profile.php?id=61578003724590" target="_blank" rel="noopener" aria-label="Facebook">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
        </a>
        <a href="https://www.instagram.com/pluskotasapp/" target="_blank" rel="noopener" aria-label="Instagram">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.5" y2="6.5"/></svg>
        </a>
        <a href="https://www.tiktok.com/@pluskotasapp" target="_blank" rel="noopener" aria-label="TikTok">
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V8.69a8.16 8.16 0 0 0 4.77 1.52V6.76a4.79 4.79 0 0 1-1.84-.07Z"/></svg>
        </a>
      </div>

      <?php if ( $is_vet_page ) : ?>
        <a href="https://app.pluskotas.com/" target="_blank" rel="noopener" class="btn btn-primary">
          <i data-lucide="stethoscope"></i>Registrarme
        </a>
      <?php else : ?>
        <a href="<?php echo esc_attr( $download_href ); ?>" class="btn btn-primary">
          <i data-lucide="download"></i>Descargar App
        </a>
      <?php endif; ?>

      <button class="menu-btn" aria-label="Abrir menú"><i data-lucide="menu"></i></button>
    </div>
  </div>
</header>
