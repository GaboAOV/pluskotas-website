<?php
$img_dir = get_template_directory_uri() . '/assets/images';
$gplay_svg = '<svg viewBox="0 0 512 512" fill="currentColor" style="width:18px;height:18px;flex-shrink:0" aria-hidden="true"><path d="M325.3 234.3L104.6 13l280.8 161.2-60.1 60.1zM47 0C34 6.8 25.3 19.2 25.3 35.3v441.3c0 16.1 8.7 28.5 21.7 35.3l232.6-232.5L47 0zM425.2 225.6l-58.9-33.9-65.7 64.5 65.7 64.5 60.1-34.3c17.2-9.8 17.2-37 0-46.8v-.5l-.7-13.9-.5-.6zm-345 239.6l280.8-161.2-60.1-60.1L47 464.2z"/></svg>';
$apple_svg  = '<svg viewBox="0 0 814 1000" fill="currentColor" style="width:16px;height:20px;flex-shrink:0" aria-hidden="true"><path d="M788.1 340.9c-5.8 4.5-108.2 62.2-108.2 190.5 0 148.4 130.3 200.9 134.2 202.2-.6 3.2-20.7 71.9-68.7 141.9-42.8 61.6-87.5 123.1-155.5 123.1s-85.5-39.5-164-39.5c-76 0-103.7 40.8-165.9 40.8s-105-57.8-155.5-127.4C46 790.7 0 663 0 541.8c0-207.5 135.4-317.3 269-317.3 70.1 0 128.4 46.4 172.5 46.4 42.8 0 109.2-49.9 190.5-49.9 30.8 0 130.3 2.6 198.3 99.2zm-234-181.5c31.1-36.9 53.1-88.1 53.1-139.3 0-7.1-.6-14.3-1.9-20.1-50.6 1.9-110.8 33.7-147.1 75.8-28.5 32.4-55.1 83.6-55.1 135.5 0 7.8 1.3 15.6 1.9 18.1 3.2.6 8.4 1.3 13.6 1.3 45.4 0 102.5-30.4 135.5-71.3z"/></svg>';
$gplay_url = 'https://play.google.com/store/apps/details?id=com.avantelogic.pluskotas&pcampaignid=web_share';
?>

<footer>
  <div class="wrap">
    <div class="foot-grid">
      <div>
        <div class="logo">
          <img src="<?php echo esc_url( $img_dir . '/logo-full-light.png' ); ?>" alt="+kotas" style="height:42px;display:block">
        </div>
        <p style="margin-top:14px;color:rgba(255,255,255,0.6);font-size:14px;max-width:280px">Veterinarios en línea, historial médico y recordatorios para tu mascota - todo en un solo lugar.</p>
        <div class="stores" style="margin-top:18px">
          <a href="<?php echo esc_url( $gplay_url ); ?>" target="_blank" rel="noopener" class="store-btn">
            <?php echo $gplay_svg; ?>
            <span><span class="small">Google Play</span></span>
          </a>
          <a href="#app-store" class="store-btn store-btn-soon">
            <?php echo $apple_svg; ?>
            <span><span class="small">Próximamente en Apple</span></span>
          </a>
        </div>
      </div>

      <div>
        <h4>Producto</h4>
        <ul>
          <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Inicio</a></li>
          <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'veterinarios' ) ) ); ?>">Para Veterinarios</a></li>
          <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'premium' ) ) ); ?>">Premium</a></li>
          <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'articulos' ) ) ); ?>">Artículos</a></li>
        </ul>
      </div>

      <div>
        <h4>Soporte</h4>
        <ul>
          <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'preguntas-frecuentes' ) ) ); ?>">Preguntas Frecuentes</a></li>
          <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'quienes-somos' ) ) ); ?>">Quiénes Somos</a></li>
        </ul>
      </div>

      <div>
        <h4>Legal</h4>
        <ul>
          <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'terminos-usuarios' ) ) ); ?>">Términos · Usuarios</a></li>
          <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'terminos-veterinarios' ) ) ); ?>">Términos · Socios Veterinarios</a></li>
          <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'privacidad-usuarios' ) ) ); ?>">Privacidad · Usuarios</a></li>
          <li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'privacidad-veterinarios' ) ) ); ?>">Privacidad · Socios Veterinarios</a></li>
        </ul>
        <h4 style="margin-top:24px">Síguenos</h4>
        <div class="socials">
          <a href="https://www.facebook.com/profile.php?id=61578003724590" target="_blank" rel="noopener" aria-label="Facebook">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
          </a>
          <a href="https://www.instagram.com/pluskotasapp/" target="_blank" rel="noopener" aria-label="Instagram">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.5" y2="6.5"/></svg>
          </a>
          <a href="https://www.tiktok.com/@pluskotasapp" target="_blank" rel="noopener" aria-label="TikTok">
            <svg viewBox="0 0 24 24" fill="currentColor" style="width:16px;height:16px"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V8.69a8.16 8.16 0 0 0 4.77 1.52V6.76a4.79 4.79 0 0 1-1.84-.07Z"/></svg>
          </a>
        </div>
      </div>
    </div>

    <div class="foot-bottom">
      <div>© <?php echo date( 'Y' ); ?> PlusKotas. Todos los derechos reservados.</div>
      <div>Hecho con 💚 para mascotas en Latinoamérica</div>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
