<?php get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>

<?php
$cats  = get_the_category();
$cat   = $cats ? $cats[0] : null;
$mins  = pluskotas_reading_time();
$thumb = get_the_post_thumbnail_url( null, 'large' );
?>

<section class="page-hero" style="padding-bottom:40px<?php echo $thumb ? ';background:var(--mint)' : ''; ?>">
  <?php if ( $cat ) : ?>
    <span class="eyebrow"><?php echo esc_html( $cat->name ); ?></span>
  <?php endif; ?>
  <h1 style="font-size:clamp(28px,4vw,52px)"><?php the_title(); ?></h1>
  <div style="display:flex;gap:16px;align-items:center;justify-content:center;margin-top:18px;font-size:13px;color:var(--muted)">
    <span><i data-lucide="clock" style="width:14px;height:14px;vertical-align:middle;margin-right:4px"></i><?php echo $mins; ?> min de lectura</span>
    <span>·</span>
    <span>Revisado por veterinario</span>
    <span>·</span>
    <span><?php echo get_the_date(); ?></span>
  </div>
</section>

<?php if ( $thumb ) : ?>
<div style="max-width:900px;margin:-20px auto 0;padding:0 24px">
  <img src="<?php echo esc_url( $thumb ); ?>" alt="<?php the_title_attribute(); ?>" style="width:100%;border-radius:var(--r-lg);box-shadow:var(--shadow-floating);display:block">
</div>
<?php endif; ?>

<section style="padding-top:<?php echo $thumb ? '48px' : '20px'; ?>">
  <div class="wrap">
    <div class="single-content legal-content">
      <?php the_content(); ?>
    </div>

    <div style="margin-top:48px;padding-top:32px;border-top:1px solid var(--border);display:flex;gap:12px;flex-wrap:wrap;align-items:center">
      <?php if ( $cat ) : ?>
        <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="btn btn-secondary" style="font-size:13px"><i data-lucide="arrow-left"></i>Más sobre <?php echo esc_html( $cat->name ); ?></a>
      <?php endif; ?>
      <a href="<?php echo esc_url( get_post_type_archive_link( 'post' ) ); ?>" class="btn btn-secondary" style="font-size:13px">Ver todos los artículos</a>
    </div>
  </div>
</section>

<?php endwhile; ?>

<section id="descargar" style="background:var(--mint)">
  <div class="wrap">
    <div class="final">
      <div style="text-align:center;max-width:720px;margin:0 auto;position:relative;z-index:2">
        <h2>¿Tienes una duda sobre tu mascota?</h2>
        <p style="margin-top:18px;font-size:17px">Agenda una consulta en línea con un veterinario verificado desde PlusKotas.</p>
        <a href="https://play.google.com/store/apps/details?id=com.avantelogic.pluskotas&pcampaignid=web_share" target="_blank" rel="noopener" class="btn btn-primary" style="background:var(--yellow);color:var(--ink);margin-top:24px"><i data-lucide="download"></i>Descargar app</a>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
