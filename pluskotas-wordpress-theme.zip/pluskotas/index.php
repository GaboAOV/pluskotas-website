<?php
// Fallback — WordPress requires this file but front-page.php and archive.php take precedence.
get_template_part( 'archive' );
