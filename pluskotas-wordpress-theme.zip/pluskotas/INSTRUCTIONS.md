# PlusKotas WordPress Theme — Installation Guide

## What you get

A complete WordPress custom theme that replicates the PlusKotas marketing site. The blog/articles section is powered by WordPress native Posts — you write articles using the WordPress editor and they appear automatically on the Artículos page.

---

## Prerequisites

- WordPress 6.0+
- A hosting account with WordPress installed (or a local development environment like LocalWP)
- FTP/SFTP or hosting file manager access

---

## Step 1 — Copy images into the theme

The theme references images from its own `assets/images/` directory.

1. Open the theme folder: `wordpress-theme/pluskotas/assets/images/`
2. Copy these files from your design export (`project/assets/`):
   - `logo-full.png` → `assets/images/logo-full.png`
   - `logo-full-light.png` → `assets/images/logo-full-light.png`
   - `logo-mark.png` → `assets/images/logo-mark.png`
   - `screens/web-perfil-vet.png` → `assets/images/screens/web-perfil-vet.png`
   - `screens/mobile-perfil-usuario.png` → `assets/images/screens/mobile-perfil-usuario.png`
   - `screens/mobile-vets-usuario.png` → `assets/images/screens/mobile-vets-usuario.png`

---

## Step 2 — Upload the theme

1. Zip the entire `pluskotas/` folder (the one containing `style.css`)
2. In your WordPress dashboard → **Appearance → Themes → Add New → Upload Theme**
3. Upload the zip file and click **Activate**

Alternatively, upload the folder directly via FTP to `wp-content/themes/pluskotas/`

---

## Step 3 — Set the homepage

1. Go to **Settings → Reading**
2. Under "Your homepage displays", select **A static page**
3. Set **Homepage** to any page (you'll create it below) — WordPress will use `front-page.php` automatically for the site root
4. Set **Posts page** to your **Artículos** page (created in Step 4)

---

## Step 4 — Create pages with the right templates

Go to **Pages → Add New** for each page below. Set the page title and assign the template from the **Page Attributes** panel on the right.

| Page Title          | Slug                   | Template                    |
|---------------------|------------------------|-----------------------------|
| Inicio              | (set as homepage)      | *(no template needed)*      |
| Artículos           | `articulos`            | *(set as Posts Page)*       |
| Premium             | `premium`              | **Premium**                 |
| Para Veterinarios   | `veterinarios`         | **Para Veterinarios**       |
| Quiénes Somos       | `quienes-somos`        | **Quiénes Somos**           |
| Preguntas Frecuentes| `preguntas-frecuentes` | **Preguntas Frecuentes**    |
| Términos · Usuarios            | `terminos-usuarios`         | *(Default Template)* |
| Términos · Socios Veterinarios | `terminos-veterinarios`     | *(Default Template)* |
| Privacidad · Usuarios          | `privacidad-usuarios`       | *(Default Template)* |
| Privacidad · Socios Veterinarios| `privacidad-veterinarios`  | *(Default Template)* |

For the legal pages (Términos, Privacidad), paste the full legal text into the page editor using WordPress blocks. The `page.php` template will wrap it in the correct styling.

**Important:** The slugs must match exactly (e.g., `veterinarios`, not `para-veterinarios`) because the theme's footer and header look up pages by their slug using `get_page_by_path()`.

---

## Step 5 — Set the Posts page (Artículos)

1. Create the **Artículos** page first (Step 4 above)
2. Go to **Settings → Reading**
3. Set **Posts page** to **Artículos**

This tells WordPress to use your `archive.php` template for that page, which displays the blog post grid automatically.

---

## Step 6 — Create article categories

The Artículos page shows category filter chips automatically based on your WordPress categories.

Go to **Posts → Categories** and create these categories (names must match what you want to display):

- Salud preventiva
- Vacunas y desparasitación
- Nutrición
- Comportamiento
- Síntomas comunes
- Cachorros y gatitos
- Mascotas senior
- Emergencias

---

## Step 7 — Write your first article

1. Go to **Posts → Add New**
2. Write your article using the block editor (headings, paragraphs, images, lists)
3. Set a **Category** from the right sidebar
4. Add a **Featured Image** — this will appear as the card thumbnail in the article grid and at the top of the single post. If no featured image is set, a colored gradient placeholder with an icon is shown.
5. Fill in the **Excerpt** (optional) — shown as the card description in the grid. If empty, WordPress auto-generates one from the post content.
6. Click **Publish**

The article will immediately appear on the Artículos page and on the homepage (up to 3 most recent posts).

---

## Step 8 — Verify permalink structure

1. Go to **Settings → Permalinks**
2. Select **Post name** (e.g., `/%postname%/`)
3. Click **Save Changes**

This gives articles clean URLs like `yourdomain.com/vacunas-esenciales/`.

---

## Step 9 — Optional: Set up the navigation menu

The header navigation is hardcoded in `header.php` for reliability, but if you want to manage it via WordPress:

1. Go to **Appearance → Menus**
2. Create a menu called **Primary**
3. Add pages and custom links (for homepage anchors like `#how` and `#benefits`)
4. Assign it to the **Primary Navigation** location

To enable WordPress menu management, edit `header.php` and replace the `<nav>` block with `wp_nav_menu()`.

---

## Step 10 — Upload your logo via WordPress (optional)

The theme also supports the WordPress custom logo feature:

1. Go to **Appearance → Customize → Site Identity**
2. Upload your logo

This is optional — the theme defaults to the images in `assets/images/`.

---

## How the blog works

```
You write a Post in WordPress
        ↓
archive.php renders it as a card in the Artículos grid
        ↓
single.php renders the full article when clicked
        ↓
Category links filter by WordPress category
```

- **Reading time** is calculated automatically from word count (~200 wpm)
- **Category label** on each card comes from the post's WordPress category
- **Featured image** appears as the card thumbnail; without one, a gradient with an icon is shown
- **Homepage articles section** shows the 3 most recent published posts automatically

---

## Updating the FAQ

The FAQ content lives as a JSON array inside `template-faq.php`. To edit questions:

1. Open `wp-content/themes/pluskotas/template-faq.php`
2. Find the `<script type="application/json" id="faq-data">` block
3. Edit the JSON array (each item has `cat`, `catLabel`, `q`, and `a` fields)
4. Save the file

To add a new category, also add it to the `catOrder` array in `assets/js/main.js`.

---

## Updating prices or content in templates

Each template file (`template-premium.php`, `template-veterinarios.php`, etc.) contains hardcoded content that can be edited directly:

| What to change | File to edit |
|---|---|
| Premium prices | `template-premium.php` |
| Veterinarian registration page content | `template-veterinarios.php` |
| Mission, Vision, Values | `template-quienes-somos.php` |
| FAQ questions & answers | `template-faq.php` |
| Homepage sections | `front-page.php` |
| Header navigation links | `header.php` |
| Footer links and social URLs | `footer.php` |
| All colors and spacing | `assets/css/main.css` (`:root` variables) |

---

## File structure overview

```
pluskotas/
├── style.css               ← Theme declaration (required by WordPress)
├── functions.php           ← Enqueue styles/scripts, theme setup
├── index.php               ← Fallback (never used normally)
├── front-page.php          ← Homepage (shown at site root)
├── header.php              ← Site header & navigation
├── footer.php              ← Site footer
├── archive.php             ← Artículos grid (blog post listing)
├── single.php              ← Individual article/post view
├── page.php                ← Generic page fallback (legal pages)
├── template-veterinarios.php   ← Para Veterinarios page
├── template-premium.php        ← Premium page
├── template-quienes-somos.php  ← Quiénes Somos page
├── template-faq.php            ← Preguntas Frecuentes page
└── assets/
    ├── css/
    │   └── main.css        ← All styles consolidated
    ├── js/
    │   └── main.js         ← Lucide icons + FAQ filter logic
    └── images/
        ├── logo-full.png
        ├── logo-full-light.png
        ├── logo-mark.png
        └── screens/
            ├── web-perfil-vet.png
            ├── mobile-perfil-usuario.png
            └── mobile-vets-usuario.png
```

---

## Troubleshooting

**Pages show blank content or wrong template**
→ Make sure the page slug matches exactly what the theme expects (e.g., `preguntas-frecuentes`)

**Images not showing**
→ Confirm images were copied to `assets/images/` inside the theme directory

**Artículos page shows blog settings instead of post grid**
→ Go to Settings → Reading → set Posts Page to your Artículos page

**Icons not rendering**
→ The Lucide icon library loads from `unpkg.com`. Check that the site can reach CDN URLs (some server firewalls block this). Alternatively, self-host lucide by downloading the script and enqueueing it locally in `functions.php`.

**Navigation links don't work**
→ The header uses `get_page_by_path()` which requires the exact page slug. Double-check the slugs of your pages in Pages → Edit → Permalink.
