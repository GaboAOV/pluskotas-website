<?php
/*
 * Template Name: Premium
 */
get_header();
$gplay_url = 'https://play.google.com/store/apps/details?id=com.avantelogic.pluskotas&pcampaignid=web_share';
?>

<section class="page-hero">
  <span class="eyebrow">PlusKotas Premium</span>
  <h1>Elige cómo quieres cuidar a tu mascota con PlusKotas</h1>
  <p>Empieza gratis y desbloquea más herramientas con PlusKotas Premium.</p>
</section>

<section style="padding-top:0">
  <div class="wrap">
    <div class="promo-banner"><i data-lucide="gift"></i>Promoción de lanzamiento: 6 meses Premium gratis si te registras durante el primer mes</div>
    <div class="compare-grid">
      <div class="plan">
        <h3>Free</h3>
        <p>Para empezar</p>
        <div class="price">$0<span> / siempre</span></div>
        <ul>
          <li><i data-lucide="check"></i>Crear perfil de usuario</li>
          <li><i data-lucide="check"></i>Registrar hasta 2 mascotas</li>
          <li><i data-lucide="check"></i>Historial médico básico</li>
          <li><i data-lucide="check"></i>Citas veterinarias con comisión de servicio</li>
          <li><i data-lucide="check"></i>Artículos informativos</li>
          <li style="opacity:0.6"><i data-lucide="x"></i>Anuncios dentro de la app</li>
        </ul>
        <a href="<?php echo esc_url( $gplay_url ); ?>" target="_blank" rel="noopener" class="btn btn-secondary" style="width:100%;justify-content:center"><i data-lucide="download"></i>Descargar PlusKotas</a>
      </div>
      <div class="plan premium">
        <span class="badge" style="background:var(--yellow);color:var(--ink)">RECOMENDADO</span>
        <h3 style="margin-top:14px">Premium</h3>
        <p style="color:rgba(255,255,255,0.8)">Todo desbloqueado</p>
        <div class="price">$4.99<span> / mes</span></div>
        <div style="font-size:13px;opacity:0.8">o $44.99 / año · 1 mes prueba gratis</div>
        <ul>
          <li><i data-lucide="check"></i>Sin comisión de servicio en citas</li>
          <li><i data-lucide="check"></i>Recordatorios desbloqueados</li>
          <li><i data-lucide="check"></i>Hasta 10 perfiles de mascotas</li>
          <li><i data-lucide="check"></i>Sin anuncios</li>
          <li><i data-lucide="check"></i>Acceso prioritario a futuras funciones</li>
          <li><i data-lucide="check"></i>1 mes de prueba gratis</li>
        </ul>
        <a href="<?php echo esc_url( $gplay_url ); ?>" target="_blank" rel="noopener" class="btn btn-primary" style="width:100%;justify-content:center;background:var(--yellow);color:var(--ink)"><i data-lucide="crown"></i>Descargar PlusKotas</a>
      </div>
    </div>
  </div>
</section>

<section style="background:var(--aqua)">
  <div class="wrap">
    <div class="section-head"><span class="eyebrow">FAQ</span><h2 style="margin-top:14px">Preguntas frecuentes</h2></div>
    <div class="faq-list">
      <div class="faq-item"><div class="faq-q">¿Qué incluye el plan gratuito?</div><div class="faq-a"><p>Gratis: sin costo mensual de afiliación, tienes la opción de incluir 2 perfiles de mascotas y la posibilidad de agendar consultas con veterinarios según tus necesidades. Los veterinarios son los que definen el costo de sus consultas en la plataforma. En este caso aplica una tarifa de servicio del 15% sobre el valor de las consultas, incluyendo la cita de seguimiento gratuita. El historial médico de la mascota está disponible. Sin acceso a los recordatorios. Es posible que veas publicidad en la aplicación.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Qué beneficios tiene el plan premium?</div><div class="faq-a"><p>Premium: por $4.99 al mes o $44.99 al año, elimina la tarifa de servicio de 15% cuando agendas consultas con los veterinarios, permite hasta 10 perfiles de mascotas, incluye recordatorios, y acceso anticipado a futuras funcionalidades.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Cuánto cuesta la suscripción?</div><div class="faq-a"><p>La suscripción Premium de PlusKotas tiene un mes gratis de prueba y posteriormente cuesta $4.99 al mes o $44.99 al año. El plan anual representa un 25% de descuento respecto al plan mensual.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Puedo probar la suscripción antes de pagar?</div><div class="faq-a"><p>Sí, tienes un mes de prueba gratuito. Para acceder a los beneficios de la suscripción Premium es necesario realizar el pago a partir de la finalización del mes de prueba.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿El costo de las consultas veterinarias están incluidas en el Plan Premium?</div><div class="faq-a"><p>No. Las consultas veterinarias online tienen un costo adicional al plan de suscripción. La suscripción te da acceso a beneficios y funciones, pero cada cita con un veterinario se cobra de manera independiente según la tarifa establecida. Recuerda que con el Plan Premium ahorras 15% en el costo de tus consultas.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿La cancelación tiene algún costo o penalidad?</div><div class="faq-a"><p>No. La cancelación de la suscripción no tiene ningún costo adicional ni penalidad. Una vez que la canceles, seguirás disfrutando de los beneficios Premium hasta que finalice el período que ya pagaste.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Qué pasa cuando cancelo mi suscripción?</div><div class="faq-a"><p>Cuando cancelas tu suscripción Premium: el periodo continúa activo hasta que finalice el ciclo que ya pagaste. Al terminar el ciclo, tu cuenta pasa automáticamente al plan Gratis, con acceso únicamente a las funciones básicas.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Seguiré teniendo acceso a mi cuenta y a los datos de mi mascota?</div><div class="faq-a"><p>Sí. Aunque canceles tu suscripción Premium, seguirás teniendo acceso a tu cuenta y a los datos de tus mascotas. El acceso a los perfiles adicionales y los recordatorios quedarán bloqueados al finalizar el ciclo de suscripción.</p></div></div>
      <div class="faq-item"><div class="faq-q">¿Puedo reactivar mi suscripción más adelante?</div><div class="faq-a"><p>Sí. Puedes reactivar tu suscripción en cualquier momento directamente desde la app, usando el botón "Suscribirse" en la sección de suscripción Premium.</p></div></div>
    </div>
    <div style="text-align:center;margin-top:36px">
      <a href="<?php echo esc_url( add_query_arg( 'cat', 'premium', get_permalink( get_page_by_path( 'preguntas-frecuentes' ) ) ) ); ?>" class="btn btn-secondary">Ver todas las preguntas <i data-lucide="arrow-right"></i></a>
    </div>
  </div>
</section>

<section id="descargar">
  <div class="wrap">
    <div class="final">
      <div style="text-align:center;max-width:720px;margin:0 auto;position:relative;z-index:2">
        <h2>Empieza tu prueba gratis hoy</h2>
        <p style="margin-top:18px;font-size:17px">Descarga PlusKotas y reclama tu código de 6 meses gratis durante el lanzamiento.</p>
        <a href="<?php echo esc_url( $gplay_url ); ?>" target="_blank" rel="noopener" class="btn btn-primary" style="background:var(--yellow);color:var(--ink);margin-top:24px"><i data-lucide="download"></i>Descargar PlusKotas</a>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
