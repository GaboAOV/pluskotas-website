<?php
function pluskotas_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'gallery', 'caption' ] );

    register_nav_menus( [
        'primary' => __( 'Primary Navigation', 'pluskotas' ),
    ] );
}
add_action( 'after_setup_theme', 'pluskotas_setup' );

function pluskotas_enqueue() {
    // Fonts
    wp_enqueue_style( 'pluskotas-fonts-cooper', 'https://fonts.cdnfonts.com/css/cooper-bt', [], null );
    wp_enqueue_style( 'pluskotas-fonts-montserrat', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800&display=swap', [], null );

    // Main stylesheet
    wp_enqueue_style( 'pluskotas-main', get_template_directory_uri() . '/assets/css/main.css', [ 'pluskotas-fonts-cooper', 'pluskotas-fonts-montserrat' ], '1.0.0' );

    // Lucide icons (via CDN, loaded as script)
    wp_enqueue_script( 'lucide', 'https://unpkg.com/lucide@latest', [], null, true );

    // Theme JS
    wp_enqueue_script( 'pluskotas-main', get_template_directory_uri() . '/assets/js/main.js', [ 'lucide' ], '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'pluskotas_enqueue' );

// Expose home URL and template dir to JS
function pluskotas_js_vars() {
    ?>
    <script>
    var PlusKotas = {
        homeUrl: <?php echo wp_json_encode( esc_url( home_url( '/' ) ) ); ?>,
        templateUrl: <?php echo wp_json_encode( esc_url( get_template_directory_uri() ) ); ?>
    };
    </script>
    <?php
}
add_action( 'wp_head', 'pluskotas_js_vars', 5 );

// Add reading time to posts
function pluskotas_reading_time( $post_id = null ) {
    $post    = get_post( $post_id );
    $content = wp_strip_all_tags( $post->post_content );
    $words   = str_word_count( $content );
    $minutes = max( 1, (int) ceil( $words / 200 ) );
    return $minutes;
}

// Excerpt length
add_filter( 'excerpt_length', function() { return 20; } );
add_filter( 'excerpt_more', function() { return '…'; } );
