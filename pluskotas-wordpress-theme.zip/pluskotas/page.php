<?php get_header(); ?>

<?php while ( have_posts() ) : the_post(); ?>

<section class="page-hero">
  <h1><?php the_title(); ?></h1>
</section>

<section>
  <div class="wrap">
    <div class="legal-content">
      <?php the_content(); ?>
    </div>
  </div>
</section>

<?php endwhile; ?>

<?php get_footer(); ?>
